<div class="card reminder">
        <div class="reminder_header">
            <h2>Final Exam 2023-2024</h2>
        </div>
        <div class="card-body reminder_body">
            <div class="time_box">
                <div class="countdown_box">
                    <span class="countdown_number" id="days">00</span>
                    <span class="countdown_title">Days</span>
                </div>
                <div class="countdown_box">
                    <span class="countdown_number" id="hours">00</span>
                    <span class="countdown_title">Hours</span>
                </div>
                <div class="countdown_box">
                    <span class="countdown_number" id="minutes">00</span>
                    <span class="countdown_title">Min</span>
                </div>
                <div class="countdown_box">
                    <span class="countdown_number" id="seconds">00</span>
                    <span class="countdown_title">Sec</span>
                </div>
            </div>
        </div>
        <div class="reminder_footer">
            <h2>Insha allah</h2>
        </div>
    </div>
<?php /**PATH C:\xampp\htdocs\light_house\resources\views/frontend/layouts/reminder.blade.php ENDPATH**/ ?>