<header>
    <div class="container">
        <div class="row">
            <div class="top_head_wrapper">
                <div class="top_logo">
                    <div class="school_logo">
                        <img src="<?php echo e(asset('frontend')); ?>/assets/images/logo/Light.png" alt="SCHOOL-OF-LIFE.png"
                            class="img-fluid">
                    </div>
                </div>
                <div class="top_head_button">
                    <div class="btn_sec">
                        <a class="cmn_btn" href="<?php echo e(route('admin.login')); ?>">Portal login</a>
                        <a class="cmn_btn">Apply now</a>
                        <!-- <a class="cmn_btn">visit satarkul Branch <span class="arrow-btn"><i
                                    class="fa-solid fa-arrow-right"></i></span></a> -->
                    </div>
                </div>
                <div class="top_social_icon">
                    <div class="social_icon_list">
                        <a href="www.facebook.com"><i class="fa-brands fa-facebook-f"></i></a>
                        <a href="www.instagram.com"><i class="fa-brands fa-instagram"></i></a>
                        <a href="www.linkdin.com"><i class="fa-brands fa-linkedin-in"></i></a>
                        <a href="www.youtube.com"><i class="fa-brands fa-youtube"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <nav class="navbar navbar-expand-lg new_nav">
        <div class="container-fluid">
            <a class="offcanvas_btn" type="button" data-bs-toggle="offcanvas" data-bs-target="#staticBackdrop"
                aria-controls="staticBackdrop">
                <i class="fa-solid fa-bars-staggered"></i>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="<?php echo e(route('home.index')); ?>">Home</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" aria-expanded="false">
                            About us
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="<?php echo e(route('about.vision')); ?>">Vision , Mission and
                                    Values</a></li>
                            <li><a class="dropdown-item" href="<?php echo e(route('about.choose')); ?>">Why choose us</a></li>
                            <li><a class="dropdown-item" href="<?php echo e(route('about.principle_message')); ?>">Principal Message
                                </a></li>
                            <li><a class="dropdown-item" href="<?php echo e(route('about.team')); ?>">Our Team</a></li>
                            <li><a class="dropdown-item" href="<?php echo e(route('curriculam')); ?>">curriculum</a></li>
                            <li><a class="dropdown-item" href="<?php echo e(route('calender')); ?>">Academic Calender</a></li>
                            <li><a class="dropdown-item" href="<?php echo e(route('campus')); ?>">campus</a></li>
                            <li><a class="dropdown-item" href="<?php echo e(route('event')); ?>">upcoming Event</a></li>
                            <li class="without_border"><a class="dropdown-item" href="<?php echo e(route('gallery')); ?>">gallery</a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="addmission.html" role="button" aria-expanded="false">
                            addmission
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="<?php echo e(route('addmission_procedure')); ?>">A brief admission Procedure</a></li>
                            <!-- <li><a class="dropdown-item" href="#">Scholarship</a></li> -->
                            <li><a class="dropdown-item" href="<?php echo e(route('fees')); ?>">School fees</a></li>
                            <!-- <li><a class="dropdown-item" href="#">Withdrawal Policy</a></li>
                            <li><a class="dropdown-item" href="addmission.html">Faq on Addmission</a></li> -->
                            <li><a class="dropdown-item" href="<?php echo e(route('how_to_apply')); ?>">How to apply</a></li>
                            <li><a class="dropdown-item" href="<?php echo e(route('applay_online')); ?>">Apply Online</a></li>
                            <li class="without_border"><a class="dropdown-item" href="<?php echo e(route('online_payment')); ?>">Online Payment</a></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" aria-current="page" href="<?php echo e(route('contuct')); ?>">Contact us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" aria-current="page" href="<?php echo e(route('achivement')); ?>">Achievements</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" aria-expanded="false">
                            Key Information
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="<?php echo e(route('notice')); ?>">noticies</a></li>
                            <li><a class="dropdown-item" href="<?php echo e(route('transport')); ?>">Transport</a></li>
                            <li><a class="dropdown-item" href="<?php echo e(route('cafeteria')); ?>">cafeteria</a></li>
                            <li><a class="dropdown-item" href="<?php echo e(route('book')); ?>">Books</a></li>
                            <li><a class="dropdown-item" href="<?php echo e(route('ielts')); ?>">Ielts</a></li>
                            <li><a class="dropdown-item" href="<?php echo e(route('summer_camp')); ?>">Summer Camp</a></li>
                            <li class="without_border"><a class="dropdown-item" href="<?php echo e(route('winter_camp')); ?>">Winter Camp</a></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" aria-current="page" href="<?php echo e(route('polices')); ?>">Polices</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" aria-current="page" href="<?php echo e(route('facilities')); ?>">Facilities</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" aria-current="page" href="<?php echo e(route('tour_request')); ?>">Request For A Tour</a>
                    </li>
                    <li class="nav-item">
                        
                        
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>
<?php /**PATH C:\xampp\htdocs\light_house\resources\views/frontend/layouts/navbar.blade.php ENDPATH**/ ?>