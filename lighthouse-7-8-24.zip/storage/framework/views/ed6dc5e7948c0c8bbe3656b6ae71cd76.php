<?php echo $__env->make('frontend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
    <?php echo $__env->make('frontend.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- offcanvas toggle start -->
    <?php echo $__env->make('frontend.layouts.offcanvas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- offcanvas toggle End -->
    <?php echo $__env->yieldContent('content'); ?>
    <!-- Exam reminder start -->
    
    <!-- exam reminder end -->
    <?php echo $__env->make('frontend.layouts.reminder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- footer section start -->
    <?php echo $__env->make('frontend.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\light_house\resources\views/frontend/layouts/main.blade.php ENDPATH**/ ?>