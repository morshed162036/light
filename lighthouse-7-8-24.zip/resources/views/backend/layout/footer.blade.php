    <!-- BEGIN: Footer-->
    <footer class="footer footer-static footer-light">

       <p class="clearfix mb-0"><span class="float-left d-inline-block">{{ date('Y') }} &copy; {{ $copyright }}</span>
            <button class="btn btn-primary btn-icon scroll-top" type="button"><i class="bx bx-up-arrow-alt"></i></button>
        </p>
    </footer>
    <!-- END: Footer-->

    @yield('js')

</body>
<!-- END: Body-->

</html>
